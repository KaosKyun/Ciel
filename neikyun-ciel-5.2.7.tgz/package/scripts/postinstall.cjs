#!/usr/bin/env node
// Ciel postinstall — s'exécute après npm install / npm update
//
// Toujours visible. Détecte les plateformes, configure, ou guide l'utilisateur.
// Désactivable avec CI=true ou --ignore-scripts

const { existsSync, readFileSync, writeFileSync, mkdirSync, copyFileSync, chmodSync, unlinkSync, readdirSync } = require("fs");
const { join, dirname } = require("path");

// ---- Version ----
const PKG = JSON.parse(readFileSync(join(__dirname, "..", "package.json"), "utf-8"));
const CIEL_VERSION = PKG.version || "0.0.0";

// ---- Couleurs ----
const c = (code, s) => process.stdout.isTTY ? `\x1b[${code}m${s}\x1b[0m` : s;
const cyan = (s) => c(36, s);
const green = (s) => c(32, s);
const yellow = (s) => c(33, s);
const bold = (s) => c(1, s);

// ---- Détection de plateforme ----
function detectPlatforms(targetDir) {
  const platforms = [];
  if (existsSync(join(targetDir, "opencode.json")) || existsSync(join(targetDir, ".opencode"))) platforms.push("OpenCode");
  if (existsSync(join(targetDir, ".claude/settings.json")) || existsSync(join(targetDir, ".claude"))) platforms.push("Claude Code");
  return platforms;
}

function resolveAssets() {
  for (const dir of [join(__dirname, "..", "assets"), join(__dirname, "..", "..", "assets")]) {
    if (existsSync(join(dir, "platforms/opencode/.opencode/agents/ciel.md"))) return dir;
  }
  return null;
}

function detectCLI(name) {
  try {
    const { execSync } = require("child_process");
    const r = execSync(name + " --version 2>&1", { stdio: "pipe", timeout: 3000, encoding: "utf8" });
    return r.length > 0 && !r.includes("not found");
  } catch { return false; }
}

// ---- Installation ----
function copyDir(src, dest) {
  if (!existsSync(src)) return 0;
  let count = 0;
  mkdirSync(dest, { recursive: true });
  for (const entry of readdirSync(src, { withFileTypes: true })) {
    const s = join(src, entry.name), d = join(dest, entry.name);
    if (entry.isDirectory()) count += copyDir(s, d);
    else { copyFileSync(s, d); if (s.endsWith(".sh")) try { chmodSync(d, 0o755); } catch {} count++; }
  }
  return count;
}

function installOpenCode(targetDir, assets) {
  let count = 0;
  // Nettoyer ancien plugin curl
  const old = join(targetDir, ".opencode/plugins/ciel.ts");
  if (existsSync(old)) { try { unlinkSync(old); count++; } catch {} }
  // Copier agents
  count += copyDir(join(assets, "platforms/opencode/.opencode/agents"), join(targetDir, ".opencode/agents"));
  // Copier commandes
  count += copyDir(join(assets, "platforms/opencode/.opencode/commands"), join(targetDir, ".opencode/commands"));
  // Copier AGENTS.md
  if (existsSync(join(assets, "platforms/opencode/AGENTS.md"))) {
    copyFileSync(join(assets, "platforms/opencode/AGENTS.md"), join(targetDir, "AGENTS.md"));
    count++;
  }
  // Patcher opencode.json
  try {
    const cfgPath = join(targetDir, "opencode.json");
    if (existsSync(cfgPath)) {
      let cfg = JSON.parse(readFileSync(cfgPath, "utf-8"));
      if (!cfg.plugin) cfg.plugin = [];
      // Remplacer ancienne ref locale par npm
      cfg.plugin = cfg.plugin.filter(p => p !== "./.opencode/plugins/ciel.ts");
      if (!cfg.plugin.includes("@neikyun/ciel")) cfg.plugin.push("@neikyun/ciel");
      if (!cfg.instructions) cfg.instructions = [];
      if (!cfg.instructions.includes("AGENTS.md")) cfg.instructions.push("AGENTS.md");
      writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + "\n", "utf-8");
      count++;
    }
  } catch {}
  return count;
}

function installClaude(targetDir, assets) {
  let count = 0;
  count += copyDir(join(assets, ".claude/agents"), join(targetDir, ".claude/agents"));
  count += copyDir(join(assets, ".claude/hooks"), join(targetDir, ".claude/hooks"));
  count += copyDir(join(assets, "commands"), join(targetDir, ".claude/commands"));
  const settings = join(assets, ".claude/settings.json");
  if (existsSync(settings)) { copyFileSync(settings, join(targetDir, ".claude/settings.json")); count++; }
  const claudeMd = join(assets, "CLAUDE.md");
  if (existsSync(claudeMd)) { copyFileSync(claudeMd, join(targetDir, "CLAUDE.md")); count++; }
  return count;
}

// ---- MAIN ----
async function main() {
  if (process.env.CI || process.env.NO_CIEL_POSTINSTALL) return;

  // INIT_CWD = répertoire où l'utilisateur a lancé npm install
  // (npm lance les lifecycle scripts dans node_modules/<pkg>/, pas dans le projet)
  const targetDir = process.env.INIT_CWD || process.cwd();
  const platforms = detectPlatforms(targetDir);
  const assetsDir = resolveAssets();

  // Toujours afficher le message Ciel (sur stderr pour être visible via npm)
  console.error(`\n  ${bold("✦ Ciel v" + CIEL_VERSION)}`);

  if (!assetsDir) {
    console.error(`  ${yellow("~")} Templates non trouvés (package corrompu ?)\n`);
    return;
  }

  if (platforms.length === 0) {
    // Aucune plateforme détectée → chercher les CLIs installées
    const hasOpenCode = detectCLI("opencode");
    const hasClaude = detectCLI("claude");

    if (!hasOpenCode && !hasClaude) {
      console.error(`  ${yellow("~")} Aucune plateforme détectée.`);
      console.error(`    Installez ${cyan("opencode")} ou ${cyan("claude")} puis relancez.`);
      console.error(`    Ou: ${green("npx ciel init")}\n`);
      return;
    }

    // Proposer de configurer les CLIs détectées
    let creer = !process.stdin.isTTY;
    if (process.stdin.isTTY) {
      const detected = [hasOpenCode && "OpenCode", hasClaude && "Claude Code"].filter(Boolean).join(" + ");
      try {
        const readline = require("readline");
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
        creer = await new Promise(r => rl.question(`  ${yellow("?")} Configurer Ciel pour ${cyan(detected)} ? ${green("(Y/n)")} `, a => { rl.close(); r(a.trim().toLowerCase() !== "n"); }));
      } catch { creer = true; }
    }

    if (!creer) {
      console.error(`  ${cyan("→")} Annulé. Utilisez ${green("npx ciel init")} plus tard.\n`);
      return;
    }

    // Configurer les plateformes détectées
    if (hasOpenCode) {
      const cfgPath = join(targetDir, "opencode.json");
      if (!existsSync(cfgPath)) {
        const cfg = { $schema: "https://opencode.ai/config.json", plugin: ["@neikyun/ciel"] };
        writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + "\n", "utf-8");
        console.error(`  ${green("✓")} opencode.json créé`);
      }
      platforms.push("OpenCode");
    }

    if (hasClaude) {
      const claudeDir = join(targetDir, ".claude");
      if (!existsSync(claudeDir)) {
        mkdirSync(claudeDir, { recursive: true });
      }
      const settingsPath = join(claudeDir, "settings.json");
      if (!existsSync(settingsPath)) {
        writeFileSync(settingsPath, JSON.stringify({}, null, 2) + "\n", "utf-8");
        console.error(`  ${green("✓")} .claude/settings.json créé`);
      }
      platforms.push("Claude Code");
    }
  }

  // Demander confirmation (sauter si non-TTY)
  let ok = true;
  if (process.stdin.isTTY) {
    try {
      const readline = require("readline");
      const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
      ok = await new Promise(r => rl.question(`  ${yellow("?")} Configurer Ciel pour ${cyan(platforms.join(" + "))} ? ${green("(Y/n)")} `, a => { rl.close(); r(a.trim().toLowerCase() !== "n"); }));
    } catch { ok = true; }
  }

  if (!ok) {
    console.error(`  ${cyan("→")} Annulé.\n`);
    return;
  }

  // Créer .ciel/
  mkdirSync(join(targetDir, ".ciel"), { recursive: true });
  if (!existsSync(join(targetDir, ".ciel/map.json")))
    writeFileSync(join(targetDir, ".ciel/map.json"), JSON.stringify({ modules: [], lastUpdated: "" }), "utf-8");
  if (!existsSync(join(targetDir, ".ciel/parking.md")))
    writeFileSync(join(targetDir, ".ciel/parking.md"), "# Ciel Parking Lot\n\n", "utf-8");

  // Installer
  let total = 0;
  for (const p of platforms) {
    const n = p === "OpenCode" ? installOpenCode(targetDir, assetsDir) : installClaude(targetDir, assetsDir);
    total += n;
    console.error(`  ${green("✓")} ${p}: ${n} fichiers`);
  }

  // Sauvegarder version
  writeFileSync(join(targetDir, ".ciel/memory.json"), JSON.stringify({ cielVersion: CIEL_VERSION, lastUpdated: new Date().toISOString() }, null, 2), "utf-8");

  console.error(`\n  ${green("✓")} Ciel v${CIEL_VERSION} installé !`);
  if (platforms.includes("OpenCode")) console.error(`    → plugin ${cyan("@neikyun/ciel")} ajouté à opencode.json`);
  if (platforms.includes("Claude Code")) console.error(`    → redémarrez ${cyan("claude .")}`);
  console.error();
}

main().catch(() => {});
